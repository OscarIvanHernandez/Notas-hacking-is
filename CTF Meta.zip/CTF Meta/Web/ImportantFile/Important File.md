# CTF META
## Objetivo
A file with important research has been infected by a virus, you must perform a forensic analysis of the file to find the flag that has been placed on it.

<�div class="row challenge-files text-center pb-3"> <�div class="col-md-4 col-sm-4 col-xs-12 file-button-wrapper d-block"> <�a class="btn btn-info btn-file mb-1 d-inline-block px-2 w-100 text-truncate" href="https://ctfd2022.anuies.mx/files/d8ccc8d0cf9a93450bcf33bfcbcb1923/Xoloitzcuintle.docx?token=eyJ1c2VyX2lkIjoxODgzLCJ0ZWFtX2lkIjo1MDYsImZpbGVfaWQiOjE4fQ.Y1A2yg.6yuaFT6iwwLTWo0YW731TrGrWhA"> <�i class="fas fa-download"><�/i> <�small> Xoloitzcuintle.docx <�/small> <�/a> <�/div> <�/div>

## Pistas
## Solucion


## Notas adicionales
## Referencias